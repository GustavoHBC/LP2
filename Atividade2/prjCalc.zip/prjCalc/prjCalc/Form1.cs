﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addition_Click(object sender, EventArgs e)
        {
            Calculate(1);
        }

        private void subtraction_Click(object sender, EventArgs e)
        {
            Calculate(2);
        }

        private void multiplication_Click(object sender, EventArgs e)
        {
            Calculate(3);
        }

        private void division_Click(object sender, EventArgs e)
        {
            Calculate(4);
        }

        public void Calculate(int type) {
            double storage;

            if (double.TryParse(txtVal1.Text, out double val1) && double.TryParse(txtVal2.Text, out double val2))
            {
                switch (type)
                {
                    case 1:
                        storage = val1 + val2;
                        txtResult.Text = storage.ToString();
                        break;
                    case 2:
                        storage = val1 - val2;
                        txtResult.Text = storage.ToString();
                        break;
                    case 3:
                        storage = val1 * val2;
                        txtResult.Text = storage.ToString();
                        break;
                    case 4:
                        storage = val1 / val2;
                        txtResult.Text = storage.ToString();
                        break;
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            txtVal1.Clear();
            txtVal2.Clear();
        }
    }
}
