﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCalcBodyMass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtHeight.Clear();
            txtResult.Clear();
            txtWeight.Clear();
            radioM.Checked = false;
            radioF.Checked = false;
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (radioM.Checked)
            {
                Calculate("M");
            }
            else 
            {
                Calculate("F"); 
            }
        }

        private void Calculate(string sex)
        {
            double storage;
            string situation = "Você está com o peso ideal";

            if ( (radioF.Checked || radioM.Checked) && double.TryParse(txtHeight.Text, out double val1) && double.TryParse(txtWeight.Text, out double val2) )
            {
                switch (sex)
                {
                    case "M":
                        storage = (72.7 * val1) - 58;
                        storage = Math.Round(storage, 3);
                        if (val2 < storage) { situation = "Coma bastante massas e doces"; }
                        if (val2 > storage) { situation = "Regime obrigatório já"; }

                        txtResult.Text = situation;
                        break;
                    case "F":
                        storage = (62.1 * val1) - 44.7;
                        storage = Math.Round(storage, 3);
                        if (val2 < storage) { situation = "Coma bastante massas e doces"; }
                        if (val2 > storage) { situation = "Regime obrigatório já"; }

                        txtResult.Text = situation;
                        break;
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
