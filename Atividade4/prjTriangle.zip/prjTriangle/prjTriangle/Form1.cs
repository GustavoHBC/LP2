﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjTriangle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtVal1.Clear();
            txtVal2.Clear();
            txtVal3.Clear();
            lblTriangle.Text = "";
        }

        private void btnTriType_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtVal1.Text, out double a) && double.TryParse(txtVal2.Text, out double b) && double.TryParse(txtVal3.Text, out double c))
            {
                if (Math.Abs(b-c) < a && a < b+c && Math.Abs(a-c) < b && b < a+c && Math.Abs(a-b) < c && c < a+b)
                {
                    if (a == b && b == c) { lblTriangle.Text = "Equilátero"; }
                    else if (a == b || a == c || b == c) { lblTriangle.Text = "Isósceles"; }
                    else { lblTriangle.Text = "Escaleno"; }
                }
                else
                {
                    MessageBox.Show("Os valores inseridos não correspondem a um triângulo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
