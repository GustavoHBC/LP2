﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCalcSalario
{
    public partial class frmCalc : Form
    {
        public frmCalc()
        {
            InitializeComponent();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtRaw.Text, out double rawSalary) && int.TryParse(txtChildrenNumber.Text, out int childrenNumber) && !String.IsNullOrEmpty(txtName.Text) && (rdF.Checked || rdM.Checked))
            {
                if (rdF.Checked)
                {
                    SalaryCalc("F", txtName.Text, childrenNumber, rawSalary / 100);
                }
                else
                {
                    SalaryCalc("M", txtName.Text, childrenNumber, rawSalary / 100);
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void SalaryCalc(string gender, string name, int childrenNumber, double salary)
        {
            string genderText, status;
            double totalSalary, inssDiscount, irpfDiscount, familySalary;

            switch (gender)
            {
                case "F":
                    if (checkMarried.Checked) { status = "Casada"; } else { status = "Solteira"; }
                    genderText = "Sra. ";

                    lblDados.Text = "Os descontos do salário do " + genderText + name + " que é " + status + " e que tem " + childrenNumber + " filho(s) são:";
                break;

                case "M":
                    if (checkMarried.Checked) { status = "Casado"; } else { status = "Solteiro"; }
                    genderText = "Sr. ";

                    lblDados.Text = "Os descontos do salário do " + genderText + name + " que é " + status + " e que tem " + childrenNumber + " filho(s) são:";
                break;
            }

            inssDiscount = InssValueCalc(salary);
            irpfDiscount = IrpfValueCalc(salary);
            familySalary = FamilyValueCalc(salary, childrenNumber);

            totalSalary = salary - (inssDiscount + irpfDiscount) + familySalary;

            if (inssDiscount <= 9.99)
            {
                txtInssValue.Mask = "$ 0,00";
            }
            else if (inssDiscount <= 99.99)
            {
                txtInssValue.Mask = "$ 00,00";
            }
            else if (inssDiscount <= 99.99)
            {
                txtInssValue.Mask = "$ 00,00";
            }

            if (irpfDiscount <= 9.99)
            {
                txtIrpfValue.Mask = "$ 0,00";
            }
            else if (irpfDiscount <= 99.99)
            {
                txtIrpfValue.Mask = "$ 00,00";
            }
            else if (irpfDiscount <= 999.99)
            {
                txtIrpfValue.Mask = "$ 000,00";
            }

            if (familySalary <= 9.99)
            {
                txtFamilyValue.Mask = "$ 0,00";
            }
            else if (familySalary <= 99.99)
            {
                txtFamilyValue.Mask = "$ 00,00";
            }
            else if (familySalary <= 999.99)
            {
                txtFamilyValue.Mask = "$ 000,00";
            }

            if (totalSalary <= 9.99)
            {
                txtSalary.Mask = "$ 0,00";
            }
            else if (totalSalary <= 99.99)
            {
                txtSalary.Mask = "$ 00,00";
            }
            else if (totalSalary <= 999.99)
            {
                txtSalary.Mask = "$ 000,00";
            }
            else if (totalSalary <= 9999.99)
            {
                txtSalary.Mask = "$ 0000,00";
            }

            totalSalary = (salary + familySalary) - (inssDiscount + irpfDiscount);

            txtInssValue.Text = String.Format("{0:F2}", inssDiscount);
            txtIrpfValue.Text = String.Format("{0:F2}", irpfDiscount);
            txtFamilyValue.Text = String.Format("{0:F2}", familySalary);

            txtSalary.Text = String.Format("{0:F2}", totalSalary);
        }

        private double InssValueCalc (double salary)
        {
            double inssDiscount;

            if (salary <= 800.47)
            {
                txtInssTax.Text = String.Format("{0:F2}", "07.65");
                inssDiscount = Math.Round(0.0765 * salary, 2);
            }
            else if (salary <= 1050)
            {
                txtInssTax.Text = String.Format("{0:F2}", "08.65");
                inssDiscount = Math.Round(0.0865 * salary, 2);
            }
            else if (salary <= 1400.78)
            {
                txtInssTax.Text = String.Format("{0:F2}", "09.00");
                inssDiscount = Math.Round(0.09 * salary, 2);
            }
            else if (salary <= 2801.56)
            {
                txtInssTax.Text = String.Format("{0:F2}", "11.00");
                inssDiscount = Math.Round(0.11 * salary, 2);
            }
            else
            {
                inssDiscount = 308.17;
            }

            return inssDiscount;
        }

        public double IrpfValueCalc (double salary)
        {
            double irpfDiscount;

            if (salary >= 1257.12 && salary <= 2512.08)
            {
                txtIrpfTax.Text = String.Format("{0:F2}", "15.00"); 
                irpfDiscount = Math.Round(0.15 * salary, 2);
            }
            else if (salary > 2512.08)
            {
                txtIrpfTax.Text = String.Format("{0:F2}", "27.50");
                irpfDiscount = Math.Round(0.275 * salary, 2);
            }
            else
            {
                irpfDiscount = 0;
            }

            return irpfDiscount;
        }

        private double FamilyValueCalc (double salary, int childrenNumber)
        {
            double familySalary;

            if (salary < 435.52)
            {
                familySalary = childrenNumber * 22.33;
            }
            else if (salary <= 654.61)
            {
                familySalary = childrenNumber * 15.74;
            }
            else
            {
                familySalary = 0;
            }

            return familySalary;
        }
    }

}
    