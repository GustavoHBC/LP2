﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjMenu
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void frmExercicio3_Load(object sender, EventArgs e)
        {

        }

        private void btnIndexOf_Click(object sender, EventArgs e)
        {
            int position;

            txtPalavra1.Text = txtPalavra1.Text;
            txtPalavra2.Text = txtPalavra2.Text;

            position = txtPalavra2.Text.IndexOf(txtPalavra1.Text);

            int lengthWord1 = txtPalavra1.Text.Length;
            int lengthWord2 = txtPalavra2.Text.Length;

            while (position >= 0) 
            {
                txtPalavra2.Text = txtPalavra2.Text.Substring(0, position) + txtPalavra2.Text.Substring(position + lengthWord1, lengthWord2 - position - lengthWord1);

                position = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
            }
        }

        private void btnReplace_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void btnReverse_Click(object sender, EventArgs e)
        {
            if (txtPalavra1.Text.Length > 0)
            {
                string txt = txtPalavra1.Text;
                char[] arr = txt.ToCharArray();
                Array.Reverse(arr);

                txt = "";

                foreach (char c in arr)
                {
                    txt = txt + c.ToString();
                }
                MessageBox.Show(txt, "Sucesso", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Preencha Palavra1 para continuar", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
