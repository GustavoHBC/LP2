﻿namespace prjLoops
{
    partial class frmExer1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxt = new System.Windows.Forms.RichTextBox();
            this.btnCountSpace = new System.Windows.Forms.Button();
            this.btnCountR = new System.Windows.Forms.Button();
            this.btnCountDoubleChar = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxt
            // 
            this.rchTxt.Location = new System.Drawing.Point(45, 38);
            this.rchTxt.Name = "rchTxt";
            this.rchTxt.Size = new System.Drawing.Size(724, 96);
            this.rchTxt.TabIndex = 0;
            this.rchTxt.Text = "";
            // 
            // btnCountSpace
            // 
            this.btnCountSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCountSpace.Location = new System.Drawing.Point(187, 180);
            this.btnCountSpace.Name = "btnCountSpace";
            this.btnCountSpace.Size = new System.Drawing.Size(120, 81);
            this.btnCountSpace.TabIndex = 1;
            this.btnCountSpace.Text = "Contador de Espaços";
            this.btnCountSpace.UseVisualStyleBackColor = true;
            this.btnCountSpace.Click += new System.EventHandler(this.btnCountSpace_Click);
            // 
            // btnCountR
            // 
            this.btnCountR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCountR.Location = new System.Drawing.Point(355, 180);
            this.btnCountR.Name = "btnCountR";
            this.btnCountR.Size = new System.Drawing.Size(120, 81);
            this.btnCountR.TabIndex = 2;
            this.btnCountR.Text = "Contador de Letras R";
            this.btnCountR.UseVisualStyleBackColor = true;
            this.btnCountR.Click += new System.EventHandler(this.btnCountR_Click);
            // 
            // btnCountDoubleChar
            // 
            this.btnCountDoubleChar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCountDoubleChar.Location = new System.Drawing.Point(511, 180);
            this.btnCountDoubleChar.Name = "btnCountDoubleChar";
            this.btnCountDoubleChar.Size = new System.Drawing.Size(120, 81);
            this.btnCountDoubleChar.TabIndex = 3;
            this.btnCountDoubleChar.Text = "Contador de Pares de Letras";
            this.btnCountDoubleChar.UseVisualStyleBackColor = true;
            this.btnCountDoubleChar.Click += new System.EventHandler(this.btnCountDoubleChar_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(355, 354);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 38);
            this.button4.TabIndex = 4;
            this.button4.Text = "Voltar";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // frmExer1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnCountDoubleChar);
            this.Controls.Add(this.btnCountR);
            this.Controls.Add(this.btnCountSpace);
            this.Controls.Add(this.rchTxt);
            this.Name = "frmExer1";
            this.Text = "Exercício 1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxt;
        private System.Windows.Forms.Button btnCountSpace;
        private System.Windows.Forms.Button btnCountR;
        private System.Windows.Forms.Button btnCountDoubleChar;
        private System.Windows.Forms.Button button4;
    }
}