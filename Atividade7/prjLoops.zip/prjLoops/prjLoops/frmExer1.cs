﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjLoops
{
    public partial class frmExer1 : Form
    {
        public frmExer1()
        {
            InitializeComponent();
        }

        private void btnCountSpace_Click(object sender, EventArgs e)
        {
            int i = 0;

            foreach (char c in rchTxt.Text)
            {
                if (c == ' ')
                    i++;
            }
            MessageBox.Show("A quantia de espaços digitados é: " + i.ToString(), "CONTADOR DE ESPAÇOS", MessageBoxButtons.OK);
        }

        private void btnCountR_Click(object sender, EventArgs e)
        {
            int letterCount = 0;

            for (int i = 0; i < rchTxt.Text.Length; i++)
            {
                if (rchTxt.Text[i] == 'r' || rchTxt.Text[i] == 'R')
                    letterCount++;
            }
            MessageBox.Show("A quantia de letras R é: " + letterCount.ToString(), "CONTADOR DE R", MessageBoxButtons.OK);
        }

        private void btnCountDoubleChar_Click(object sender, EventArgs e)
        {
            int countIsRepeating = 0;
            char letterBefore = '\0';

            foreach (char c in rchTxt.Text)
            {
                if (c == letterBefore)
                {
                    countIsRepeating++;
                }

                letterBefore = c;
            }
            MessageBox.Show("A quantia de letras repetidas é: " + countIsRepeating.ToString(), "CONTADOR DE PARES", MessageBoxButtons.OK);
        }
    }
}
