﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjLoops
{
    public partial class frmExer2 : Form
    {
        public frmExer2()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double H = 0;
            int numberN = 0;

            Int32.TryParse(txtNumber.Text, out numberN);

            if (numberN == 0)
                MessageBox.Show("N números precisam ser maior que 0", "Erro 400", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                for (double i = 1; i <= numberN; i++)
                {
                    H += 1 / i;
                }
                H = Math.Round(H, 4);

                MessageBox.Show("O valor de H baseado em N é: " + H, "Sucesso", MessageBoxButtons.OK);
            }
        }
    }
}
