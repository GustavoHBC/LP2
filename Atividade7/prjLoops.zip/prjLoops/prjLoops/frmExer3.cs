﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjLoops
{
    public partial class frmExer3 : Form
    {
        public frmExer3()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnPalin_Click(object sender, EventArgs e)
        {
            string palin;
            int i = 0;

            palin = txtPalin.Text;
            i = palin.IndexOf(' ');

            while (i > 0)
            {
                palin = palin.Substring(0, i) + palin.Substring(i + 1, palin.Length - i - 1);
                i = palin.IndexOf(' ');
            }

            string p = palin;
            char[] arr = p.ToCharArray();
            Array.Reverse(arr);

            p = "";

            foreach (char c in arr) { p = p + c.ToString(); }

            if (palin == p)
                MessageBox.Show("A frase inserida é um Palíndromo \n\n" + palin + "\n" + p, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("A frase inserida não é um Palíndromo \n\n" + palin + "\n" + p, "Erro 400", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
