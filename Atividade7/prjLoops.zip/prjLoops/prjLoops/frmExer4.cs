﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjLoops
{
    public partial class frmExer4 : Form
    {
        public frmExer4()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double RawSal = 0, LiqSal = Convert.ToDouble(txtSalary.Text),  aux1 = 0, aux2 = 0, aux3 = 0, Prod = Convert.ToDouble(txtProd.Text), Grat = Convert.ToDouble(txtGrat.Text);

            if (Prod >= 100)
            {
                if (Prod >= 120)
                {
                    if (Prod >= 150)
                    {
                        aux1 = 1;
                        aux2 = 1;
                        aux3 = 1;
                    }
                    else
                    {
                        aux1 = 1;
                        aux2 = 1;
                        aux3 = 0;
                    }
                }
                else
                {
                    aux1 = 1;
                    aux2 = 0;
                    aux3 = 0;
                }
            }

            RawSal = LiqSal + (LiqSal * (0.05 * aux1 + 0.1 * aux2 + 0.1 * aux3)) + Grat;

            if (RawSal > 7000)
            {
                if (Prod < 150 || Grat <= 0)
                {
                    MessageBox.Show("Salário Acima do Teto\n " + RawSal, "Erro 400", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show(
                        "Nome do funcionário: " + txtName.Text.ToString() + "\n" +
                        "Cargo: " + txtRole.Text.ToString() + "\n" +
                        "Inscrição: " + txtSubNumber.Text.ToString() + "\n" +
                        "Salário Líquido: R$" + LiqSal + "\n" +
                        "Salario Bruto: R$" + RawSal,
                        "Tabela",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
            }
            else
            {
                MessageBox.Show(
                    "Nome do funcionário: " + txtName.Text.ToString() + "\n" + 
                    "Cargo: " + txtRole.Text.ToString() + "\n" +
                    "Inscrição: " + txtSubNumber.Text.ToString() + "\n" +
                    "Salário Líquido: R$" + LiqSal + "\n" +
                    "Salario Bruto: R$" + RawSal,
                    "Tabela",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }
    }
}
