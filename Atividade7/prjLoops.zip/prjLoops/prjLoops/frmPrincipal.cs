﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjLoops
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExer1_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExer1"];

            if (fc != null) fc.Close();

            frmExer1 frm = new frmExer1();
            frm.Show();
        }

        private void btnExer2_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExer2"];

            if (fc != null) fc.Close();

            frmExer2 frm = new frmExer2();
            frm.Show();
        }

        private void btnExer3_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExer3"];

            if (fc != null) fc.Close();

            frmExer3 frm = new frmExer3();
            frm.Show();
        }

        private void btnExer4_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExer4"];

            if (fc != null) fc.Close();

            frmExer4 frm = new frmExer4();
            frm.Show();
        }
    }
}
