﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482013012
{
    public partial class frmTest : Form
    {
        public frmTest()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            lbValues.Items.Clear();

            int[,] months = new int[2, 4];

            string weekValue;
            double monthValue = 0;
            double totalValue = 0;


            for (int month = 0; month < 2; month++)
            {
                for (int week = 0; week < 4; week++)
                {
                    weekValue = Interaction.InputBox("Insira o valor recebido na semana " + (week + 1) + " do mês " + (month + 1), "Digite os valores", "0");
                    double value;

                    try {
                        value = Double.Parse(weekValue);
                        months[month, week] = Convert.ToInt32(value);
                        monthValue += value;
                        totalValue += value;
                    }
                    catch { 
                        value = 0;
                        DialogResult diag = MessageBox.Show("Deseja mesmo cancelar e limpar a lista atual ?", "Cancelar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (diag == DialogResult.Yes)
                        {
                            lbValues.Items.Clear();
                            return;
                        }
                    }

                    lbValues.BeginUpdate();
                    lbValues.Items.Add("Total do mês: " + (month + 1) + " semana " + (week + 1) + " = " + String.Format("{0:C2} ", value));
                    lbValues.EndUpdate();
                }

                lbValues.BeginUpdate();
                lbValues.Items.Add(">> Total do mês: " + String.Format("{0:C2} ", monthValue));
                lbValues.Items.Add("_______________________________");
                lbValues.EndUpdate();

                monthValue = 0;
            }

            lbValues.BeginUpdate();
            lbValues.Items.Add(">> Total Geral: " + String.Format("{0:C2} ", totalValue));
            lbValues.Items.Add("_______________________________");
            lbValues.EndUpdate();

            totalValue = 0;
        }
    }
}
